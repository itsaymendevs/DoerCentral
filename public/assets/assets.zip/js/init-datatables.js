
// $(document).ready(function() {
//     $('#memoir--table').dataTable({
//         searching: false,
//         paging: false,
//     })
// });